//
//  ViewController.swift
//  NotesUI
//
//  Created by KRUNCH TIME on 11/24/20.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource
{
    
    @IBOutlet var table: UITableView!
    @IBOutlet var label: UILabel!
    
    var noteModel: [(title: String, note: String)] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        table.dataSource = self
        table.delegate = self
        title = "Home Page Notes"
        
    }
    
    @IBAction func didTapNewNote()
    {
        guard let viewcon = storyboard?.instantiateViewController(identifier: "new") as? EntryViewController else
        {
            return
        }
        viewcon.title = "Enter New Note"
        viewcon.completion = { noteTitle, note in
            self.navigationController?.popToRootViewController(animated: true)
            self.noteModel.append((title: noteTitle, note: note))
            
            self.table.isHidden = false
            self.label.isHidden = true
            
            self.table.reloadData()
            
        }
        navigationController?.pushViewController(viewcon, animated: true)
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let nModel = noteModel[indexPath.row]
        
        guard let viewcon = storyboard?.instantiateViewController(identifier: "note") as? NoteViewController else
        {
            return
        }
        viewcon.navigationItem.largeTitleDisplayMode = .never
        viewcon.title = "View"
        viewcon.noteTitle = nModel.title
        viewcon.note = nModel.note
        navigationController?.pushViewController(viewcon, animated: true)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let boxcell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        boxcell.textLabel?.text = noteModel[indexPath.row].title
        boxcell.detailTextLabel?.text = noteModel[indexPath.row].note
            
        return boxcell
    }
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return noteModel.count
    }
        
}
