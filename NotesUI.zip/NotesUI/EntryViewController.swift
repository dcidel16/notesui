//
//  EntryViewController.swift
//  NotesUI
//
//  Created by KRUNCH TIME on 11/24/20.
//

import UIKit

class EntryViewController: UIViewController
{
    //initialize
    
    @IBOutlet var noteField: UITextView!
    
    @IBOutlet var titleField: UITextField!

    public var completion: ((String, String) -> Void)?

    override func viewDidLoad()
    {
        super.viewDidLoad()
        titleField.becomeFirstResponder()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save Note", style: .done, target: self, action: #selector(didTapSave))
    }
    
    @objc func didTapSave()
    {
        if let text = titleField.text, !text.isEmpty, !noteField.text.isEmpty
        {
            completion?(text, noteField.text)
        }
    }

}
