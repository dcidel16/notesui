//
//  NoteViewController.swift
//  NotesUI
//
//  Created by KRUNCH TIME on 11/24/20.
//

import UIKit

class NoteViewController: UIViewController
{
    //initialize empty strings and variables
    @IBOutlet var noteLabel: UITextView!
    @IBOutlet var titleLabel: UILabel!
    public var note: String = ""
    public var noteTitle: String = ""
    
    //override function and then se the text

    override func viewDidLoad()
    {
        super.viewDidLoad()
        noteLabel.text = note
        titleLabel.text = noteTitle
    }
    


}
